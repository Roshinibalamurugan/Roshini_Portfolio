import React, { useEffect, useState } from 'react'
import View from './View';
import axios from 'axios';

function Task() {

    const[value,setValue] = useState("")
    const[data,setData] = useState([])

    async function getData() {    //should be out of useEffect or else it may o/p n times 
        let response = await axios.get("http://localhost:2000/api/v1/todo")    //backend should run for axios
        console.log(response);
        setData(response.data)  //data will be displayed in o/p screen
    }

    useEffect(()=>{
        getData()    //to display data in console
    },[]) 

    async function handleClick(e){
       e.preventDefault();

       const res = await axios.post("http://localhost:2000/api/v1/todo",{
        task:value
       })
    //    setData(...data,{task:value});
       setData([])
    }

  return (
    <div>
        <form>
            <label htmlFor='addtask'>Enter task</label>
            <input value={value} onChange={(e)=>setValue(e.target.value)} type='text' id='addtask'/>
            <button onClick={(e)=>handleClick(e)}>add</button>
        </form>
        

        {/* WRAPPING VIEW COMPONENT */}

        {/* <View task={"hello.."}/> */}
        {/* {data.map((i,k)=><View key={i._id} task={i.task}/>)}    (or below) */}

        {
           data.length>0 && data.map((i,k)=><View key={i._id} id={i._id} handleUpdate={getData} task={i.task}/>)
        }

    </div>
  )
}

export default Task