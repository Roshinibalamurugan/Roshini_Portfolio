import React, { useState } from 'react'
import axios from 'axios'

function View({task,id,handleUpdate}) {      //{task,id,handleUpdate} - importing from task
  
  const[toggle,setToggle] = useState(false)  //false - default
  const[data,setData] = useState("")
  
  async function handleclick(){
    await axios.delete(`http://localhost:2000/api/v1/todo/${id}`)
    handleUpdate()       //to delete automatically
  }
   
  
  async function handleupdateServer(e){
    e.preventDefault()
    await axios.put(`http://localhost:2000/api/v1/todo/${id},{task:data}`)
    handleUpdate()
  }
  
  return (
    <div>
        <h2>{task}</h2>
        <button onClick={handleclick}>delete</button>
        <button onClick={()=>setToggle(!toggle)}>update</button>
        {
          toggle && <form>
          <input type='text' value={data} onChange={(e)=>setData(e.target.value)}/>
          <button onClick={(e)=>handleupdateServer(e)}>UPDATE</button>
          </form>
        }

    </div>
  )
}

export default View